/* En este archivo se implementan todas las funciones para listas
*  Recordar que C++ te permite definir las funciones en cualquier parte del codigo
*  pero recuerde ser ordenado y documento las funciones
*/
#include <iostream>
// Implementaciones para funciones de listas Simples
#include "listas.h"


struct nodo* insertarListaS(float verX, float verY, struct nodo* sprimero)
{
	// Insertamos un nodo recordar que las listas simples insertan al inicio
	// Pueden hacer una funcion para insertar al final tambien

	struct nodo* nuevonodo = new nodo();
	nuevonodo->verticeX = verX;
	nuevonodo->verticeY = verY;
	nuevonodo->sig = sprimero;  // recordar que los struct se acceden de esta forma cuando son punteros
	return nuevonodo;       // modificamos la direccion del nuevo primero
	// Insertar es un funcion sensilla
	// El ultimo nodo de la lista debe estar siempre apuntando a null sino nos podemos lopear
}

void imprimirListaSNormal(struct nodo* sprimero)
{
	// Imprmir una lista simple no tiene mayor complejidad
	struct nodo* snodo = sprimero; // recuerden siempre iniciar sus variables con el tipo de datos
	
	while (snodo != nullptr)
	{
		// vamos a recorrer la lista imprimiendo en consola
		std::cout << snodo->verticeX << "," << snodo->verticeY << std::endl;
		snodo = snodo->sig; // nos movemos al siguiente

	}
}


// Vamos a imprimir la lista del ultimo al primero de manera recursiva :)
void imprimirListaSinversa(struct nodo* snodoinicial)
{
	// Esta es nuestra condiciones de parada para que nuestro algoritmo no se quede al indifinito
	// por eso nunca se debe dejar el puntero sig del ultimo nodo apuntando a otro nodo
	if (snodoinicial == NULL)
		return;

	imprimirListaSinversa(snodoinicial->sig);
	std::cout << snodoinicial->verticeX << "," << snodoinicial->verticeY << std::endl;

}

// La funcion de buscar es muy util cuando tenemos listas grandes o queremos
// insertar en otro lado, o cuando vamos a borrar
bool buscarVerticeLS(float fverX, float fverY, struct nodo* sprimero)
{
	// Si la lista esta vacia retornamos
	if (sprimero == nullptr)
	{
		std::cout << "Lista Vacia" << std::endl;
	}
	// Necesitamos un temporal para recorrer la lista
	// no queremo perder el inicio de lista

	struct nodo* nnodotemp = sprimero;
	while (nnodotemp != nullptr)
	{
		if ((nnodotemp->verticeX == fverX) && (nnodotemp->verticeY == fverY))
			return true;

		nnodotemp = nnodotemp->sig; // seguimos buscando
	}
	return false; // si no lo encontramos
}

// Fin de funciones de para lista simples

/*
	En adelante solo hasta que se indique solo se encontrar funciones para
	listas circulares, tendran una C que lo indica
*/

// Esta funcion debe ir buscando el nodo fin para apuntar ese nodo al inicio
struct nodo* insertarListaC(float verX, float verY, struct nodo* sprimero)
{
	struct nodo* nuevonodo = new nodo();
	nuevonodo->verticeX = verX;
	nuevonodo->verticeY = verY;

	// Si es el primer nodo que se inserta apunta a si mismo
	if (sprimero == NULL)
		nuevonodo->sig = nuevonodo;
	else
	{
		//necesitamos movernos en la lista
		struct nodo* snodotemp = sprimero;
		// podemos usar un do while ya que sabemos que tenemos almenos un elemento
		do
		{
			snodotemp = snodotemp->sig;
		} while (snodotemp->sig != sprimero);
		snodotemp->sig = nuevonodo;
		nuevonodo->sig = sprimero;
	}
	sprimero = nuevonodo;
	return sprimero;
}

// Debemos copiar cual es la direccion del primer nodo como es circular,
// sera nuestra unica referencia para no quedar en un ciclo continuo
void imprimirListaC(struct nodo* sprimero)
{
	struct nodo* snodotemp;
	if (sprimero == NULL)
		return;

	snodotemp = sprimero; // iniciamos en el primero
	do {
		std::cout << snodotemp->verticeX << "," << snodotemp->verticeY << std::endl;
		snodotemp = snodotemp->sig;
	} while (snodotemp != sprimero);

}

//  Fin funciones de Circular

/* En adelante funciones para listas dobles*/

// Insercion en lista Doble al inicio
struct nododoble* insertarListaD(float verX, float verY, struct nododoble* scabezadoble)
{
	struct nododoble *snodonuevo = new nododoble();
	snodonuevo->verticeX = verX;
	snodonuevo->verticeY = verY;

	if (scabezadoble == NULL) // Primero en la lista
		scabezadoble = snodonuevo;
	else
	{
		scabezadoble->anterior = snodonuevo;
		snodonuevo->siguiente = scabezadoble;
		scabezadoble = snodonuevo;
	}
	return scabezadoble;
}

// Insercion en lista doble al final
void insertarListaDFinal(float verX, float verY, struct nododoble* scabezadoble)
{
	struct nododoble *snodonuevo = new nododoble();
	snodonuevo->verticeX = verX;
	snodonuevo->verticeY = verY;

	if (scabezadoble == NULL) // inicio de lista
		scabezadoble = snodonuevo;
	else
	{
		struct nododoble* snodotemp = scabezadoble;
		while (snodotemp->siguiente != NULL)
		{
			snodotemp = snodotemp->siguiente;
		}
		snodotemp->siguiente = snodonuevo;
		snodonuevo->anterior = snodotemp;
	}
}


// Insercion en lista doble de manera ordenada
void insertarListaDOrdenado(float verX, float verY, struct nododoble* scabezadoble)
{
	struct nododoble* snodonuevo = new nododoble();
	snodonuevo->verticeX = verX;
	snodonuevo->verticeY = verY;

	if (scabezadoble == NULL)
		scabezadoble = snodonuevo;
	else
	{
		struct nododoble* snodoactual = scabezadoble;
		struct nododoble* snodoanterior = NULL;

		while ((snodoactual != NULL) && (verX > snodoactual->verticeX))
		{
			snodoanterior = snodoactual;
			snodoactual = snodoactual->siguiente;
		}
		if (snodoactual == NULL) // queremos insertar al final de la lista
		{
			snodoanterior->siguiente = snodonuevo;
			snodonuevo->anterior = snodoanterior;
		}
		else if (snodoanterior == NULL) // se inserta al inicio
		{
			snodonuevo->siguiente = scabezadoble;
			scabezadoble->anterior = snodonuevo;
			scabezadoble = snodonuevo;
		}
		else
		{
			snodoanterior->siguiente = snodonuevo;
			snodoactual->anterior = snodonuevo;
			snodonuevo->siguiente = snodoactual;
			snodonuevo->anterior = snodoanterior;
		}
	}

}

// Borrado en listas dobles el primero de la lista
struct nododoble* borradoListaD(struct nododoble* scabezadoble)
{
	if (scabezadoble == NULL)
	{
		std::cout << "Lista vacia" << std::endl;
		return NULL;
	}
	struct nododoble* snodoAborrar = scabezadoble;
	scabezadoble = scabezadoble->siguiente;
	scabezadoble->anterior = NULL;
	delete snodoAborrar; // en C++ se debe borrar la memoria sino el espacio queda ocupado y perdido
	return scabezadoble;
}

// Borrado en una lista doble de un elemento especifico
// Aqui utilizamos una sobre carga de funcion ya que se llama igual a otra 
// eso es genial para cuando tenemos funciones que hacer trabajos diferentes con parametros diferentes
// pero sobre la misma abstraccion. La condicion es que no pueden tener los mismos parametros :)
struct nododoble* borradoListaD(float verX, float verY, struct nododoble* scabezadoble)
{
	if (scabezadoble == NULL)
	{
		std::cout << "Lista vacia" << std::endl;
		return NULL;
	}
	struct nododoble* snodoAborrar = scabezadoble;
	while ((snodoAborrar != NULL) && (snodoAborrar->verticeX != verX) && (snodoAborrar->verticeY != verY))
		snodoAborrar = snodoAborrar->siguiente;

	if (snodoAborrar == NULL)
		std::cout << "No se encuentra en la lista \n";
	else if (snodoAborrar == scabezadoble) // es el primero de la lista
	{
		scabezadoble = scabezadoble->siguiente;
		if (scabezadoble != NULL)
			scabezadoble->anterior = NULL;
	}
	else
	{
		snodoAborrar->anterior->siguiente = snodoAborrar->siguiente;
		if (snodoAborrar->siguiente != NULL)
			snodoAborrar->siguiente->anterior = snodoAborrar->anterior;
	}
	delete snodoAborrar;
	return scabezadoble;
}

// Imprimir la lista del final al inicio pero usando recursividad
void imprimirListaDNormal(struct nododoble* scabezadoble)
{
	struct nododoble* snodotemp = scabezadoble;
	struct nododoble* snodotempAnterior;

	if (scabezadoble == NULL)
		return;
	
	do {
		snodotempAnterior = snodotemp;
		std::cout << snodotemp->verticeX << "," << snodotemp->verticeY << std::endl;
		snodotemp = snodotemp->siguiente;
	} while (snodotemp != NULL);

	while (snodotempAnterior != NULL)
	{
		std::cout << snodotempAnterior->verticeX << "," << snodotempAnterior->verticeY << std::endl;
		snodotempAnterior = snodotempAnterior->anterior;
	}
}