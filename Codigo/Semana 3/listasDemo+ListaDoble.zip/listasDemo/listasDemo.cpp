// listasDemo.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "listas.h"

struct nodo* snodoinicial;
struct nodo* snodoCircularinicial;
struct nododoble* snododobleInicial;

// se declaran aca para que el compilador no de error
void demoListasCirculares();
void demoListasSimples();
void demoListasDobles();


int main()
{
    int iselec;
    
    do
    {
        std::cout << std::endl << std::endl;
        std::cout << "Demo de listas!" << std::endl;
        std::cout << "Seleccione una opcion" << std::endl;
        std::cout << "1) Listas Simples" << std::endl;
        std::cout << "2) Listas Circulares" << std::endl;
        std::cout << "3) Listas Dobles" << std::endl;
        std::cout << "4) Salir" << std::endl;
        std::cin >> iselec;

        switch (iselec)
        {
        case 1:
            demoListasSimples();
            break; // sin esto el swith retorna en la siguiente linea y pregunta por le siguiente case
        case 2:
            demoListasCirculares();
            break;
        case 3:
            demoListasDobles();
            break; 
        default:
            break;
        }
    } while (iselec != 4);
    
    
    
}

void demoListasCirculares()
{
    std::cout << "Vamos a insertar en Circular" << std::endl;
    snodoCircularinicial = insertarListaC(10.5f, 45.5f, snodoCircularinicial);
    snodoCircularinicial = insertarListaC(20.5f, 30.5f, snodoCircularinicial);
    snodoCircularinicial = insertarListaC(10.5f, 40.5f, snodoCircularinicial);
    std::cout << "Imprimimos todos" << std::endl;
    imprimirListaC(snodoCircularinicial);
    std::cout << "-- FIN --" << std::endl;

    std::cout << "Digite cualquier tecla + enter para continuar" << std::endl;
    char enter;
    std::cin >> enter;
}

void demoListasSimples()
{
    std::cout << "Vamos a insertar" << std::endl;
    snodoinicial = insertarListaS(3.5f, 5.5f, snodoinicial);
    snodoinicial = insertarListaS(2.5f, 3.5f, snodoinicial);
    snodoinicial = insertarListaS(1.5f, 4.5f, snodoinicial);
    std::cout << "Imprimimos todos" << std::endl;
    imprimirListaSNormal(snodoinicial);
    std::cout << "Imprimimos desde el final" << std::endl;
    imprimirListaSinversa(snodoinicial);
    std::cout << "Buscamos el segundo" << std::endl;
    bool resultado;
    resultado = buscarVerticeLS(2.5f, 3.5f, snodoinicial);
    if (resultado)
        std::cout << "Lo encontramos" << std::endl;
    else
        std::cout << "No lo encontramos" << std::endl;
    std::cout << std::endl << std::endl;
    
    std::cout << "Digite cualquier tecla + enter para continuar" << std::endl;
    char enter;
    std::cin >> enter;

}

void demoListasDobles()
{
    std::cout << std::endl << std::endl;
    std::cout << "Vamos a insertar en lista doble" << std::endl;
    snododobleInicial = insertarListaD(10, 15, snododobleInicial);
    snododobleInicial = insertarListaD(15, 20, snododobleInicial);
    snododobleInicial = insertarListaD(17, 21, snododobleInicial);
    snododobleInicial = insertarListaD(18, 25, snododobleInicial);
    insertarListaDFinal(40, 100, snododobleInicial);
    insertarListaDFinal(44, 120, snododobleInicial);
    insertarListaDFinal(47, 126, snododobleInicial);
    imprimirListaDNormal(snododobleInicial);
    snododobleInicial = borradoListaD(snododobleInicial); //borramos el primero 10,15
    snododobleInicial= borradoListaD(40, 100, snododobleInicial);  // uso la sobre carga para borrar uno especifico
    imprimirListaDNormal(snododobleInicial);
    std::cout << "Digite cualquier tecla + enter para continuar" << std::endl;
    char enter;
    std::cin >> enter;

}